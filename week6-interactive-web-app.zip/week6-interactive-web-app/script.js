/*
 * Week 6 Assignment - Interactive Web Application
 * This script demonstrates advanced JavaScript concepts including:
 * - Event handling for various user interactions
 * - Custom interactive features
 * - Comprehensive form validation
 * - DOM manipulation and dynamic content
 */

// ===========================================
// GLOBAL VARIABLES AND INITIALIZATION
// ===========================================

// I'm using an object to store application state for better organization
const appState = {
    currentTheme: {
        primary: '#4a90e2',
        background: '#f8f9fa',
        text: '#333333'
    },
    tasks: JSON.parse(localStorage.getItem('tasks')) || [],
    currentImageIndex: 0,
    galleryImages: []
};

// ===========================================
// PART 1: EVENT HANDLING
// ===========================================

// This function sets up all event listeners when the DOM is loaded
function initializeEventListeners() {
    console.log("Initializing event listeners...");

    // Form submission handling
    const registrationForm = document.getElementById('registrationForm');
    registrationForm.addEventListener('submit', handleFormSubmit);

    // Real-time form validation
    setupRealTimeValidation();

    // Task manager events
    document.getElementById('addTaskBtn').addEventListener('click', addNewTask);
    document.getElementById('taskInput').addEventListener('keypress', function(e) {
        if (e.key === 'Enter') addNewTask();
    });
    document.getElementById('clearCompleted').addEventListener('click', clearCompletedTasks);
    document.getElementById('clearAll').addEventListener('click', clearAllTasks);

    // Color theme events
    document.getElementById('applyColors').addEventListener('click', applyCustomTheme);
    document.getElementById('resetColors').addEventListener('click', resetTheme);

    // Gallery events
    document.getElementById('shuffleGallery').addEventListener('click', shuffleGallery);
    document.getElementById('filterLandscape').addEventListener('click', () => filterGallery('landscape'));
    document.getElementById('filterPortrait').addEventListener('click', () => filterGallery('portrait'));
    document.getElementById('showAll').addEventListener('click', () => filterGallery('all'));

    // Lightbox events
    document.querySelector('.lightbox-close').addEventListener('click', closeLightbox);
    document.querySelector('.lightbox-prev').addEventListener('click', showPreviousImage);
    document.querySelector('.lightbox-next').addEventListener('click', showNextImage);

    // Keyboard navigation for lightbox
    document.addEventListener('keydown', handleKeyboardNavigation);

    // Close lightbox when clicking outside the image
    document.getElementById('lightbox').addEventListener('click', function(e) {
        if (e.target === this) closeLightbox();
    });
}

// ===========================================
// PART 2: CUSTOM INTERACTIVE FEATURES
// ===========================================

// FEATURE 1: Dynamic Task Manager with Local Storage
function initializeTaskManager() {
    console.log("Initializing task manager...");
    renderTaskList();
    updateTaskStats();
}

function addNewTask() {
    const taskInput = document.getElementById('taskInput');
    const taskText = taskInput.value.trim();

    if (taskText === '') {
        showNotification('Please enter a task!', 'warning');
        return;
    }

    const newTask = {
        id: Date.now(), // Using timestamp as unique ID
        text: taskText,
        completed: false,
        createdAt: new Date().toISOString()
    };

    appState.tasks.push(newTask);
    saveTasksToLocalStorage();
    renderTaskList();
    updateTaskStats();
    
    taskInput.value = '';
    showNotification('Task added successfully!', 'success');
}

function renderTaskList() {
    const taskList = document.getElementById('taskList');
    taskList.innerHTML = '';

    if (appState.tasks.length === 0) {
        taskList.innerHTML = '<p class="no-tasks">No tasks yet. Add your first task above!</p>';
        return;
    }

    appState.tasks.forEach(task => {
        const taskElement = createTaskElement(task);
        taskList.appendChild(taskElement);
    });
}

function createTaskElement(task) {
    const taskDiv = document.createElement('div');
    taskDiv.className = `task-item ${task.completed ? 'completed' : ''}`;
    taskDiv.innerHTML = `
        <div class="task-content">
            <input type="checkbox" ${task.completed ? 'checked' : ''} 
                   onchange="toggleTaskCompletion(${task.id})">
            <span class="task-text">${task.text}</span>
        </div>
        <div class="task-actions">
            <button onclick="editTask(${task.id})" class="btn btn-outline">Edit</button>
            <button onclick="deleteTask(${task.id})" class="btn btn-outline">Delete</button>
        </div>
    `;
    
    taskDiv.classList.add('fade-in');
    return taskDiv;
}

function toggleTaskCompletion(taskId) {
    const task = appState.tasks.find(t => t.id === taskId);
    if (task) {
        task.completed = !task.completed;
        saveTasksToLocalStorage();
        renderTaskList();
        updateTaskStats();
    }
}

function editTask(taskId) {
    const task = appState.tasks.find(t => t.id === taskId);
    if (!task) return;

    const newText = prompt('Edit your task:', task.text);
    if (newText !== null && newText.trim() !== '') {
        task.text = newText.trim();
        saveTasksToLocalStorage();
        renderTaskList();
        showNotification('Task updated!', 'success');
    }
}

function deleteTask(taskId) {
    if (confirm('Are you sure you want to delete this task?')) {
        appState.tasks = appState.tasks.filter(t => t.id !== taskId);
        saveTasksToLocalStorage();
        renderTaskList();
        updateTaskStats();
        showNotification('Task deleted!', 'success');
    }
}

function clearCompletedTasks() {
    const completedCount = appState.tasks.filter(t => t.completed).length;
    if (completedCount === 0) {
        showNotification('No completed tasks to clear!', 'info');
        return;
    }

    if (confirm(`Clear ${completedCount} completed task(s)?`)) {
        appState.tasks = appState.tasks.filter(t => !t.completed);
        saveTasksToLocalStorage();
        renderTaskList();
        updateTaskStats();
        showNotification('Completed tasks cleared!', 'success');
    }
}

function clearAllTasks() {
    if (appState.tasks.length === 0) {
        showNotification('No tasks to clear!', 'info');
        return;
    }

    if (confirm('Clear ALL tasks? This cannot be undone.')) {
        appState.tasks = [];
        saveTasksToLocalStorage();
        renderTaskList();
        updateTaskStats();
        showNotification('All tasks cleared!', 'success');
    }
}

function updateTaskStats() {
    const total = appState.tasks.length;
    const completed = appState.tasks.filter(t => t.completed).length;
    const pending = total - completed;

    document.getElementById('totalTasks').textContent = total;
    document.getElementById('completedTasks').textContent = completed;
    document.getElementById('pendingTasks').textContent = pending;
}

function saveTasksToLocalStorage() {
    localStorage.setItem('tasks', JSON.stringify(appState.tasks));
}

// FEATURE 2: Interactive Color Theme Customizer
function applyCustomTheme() {
    const primaryColor = document.getElementById('primaryColor').value;
    const backgroundColor = document.getElementById('backgroundColor').value;
    const textColor = document.getElementById('textColor').value;

    // Update application state
    appState.currentTheme = { primary: primaryColor, background: backgroundColor, text: textColor };

    // Apply colors to CSS variables
    document.documentElement.style.setProperty('--primary-color', primaryColor);
    document.documentElement.style.setProperty('--background-color', backgroundColor);
    document.documentElement.style.setProperty('--text-color', textColor);

    // Update preview
    updateColorPreview(primaryColor, backgroundColor, textColor);
    
    showNotification('Theme applied successfully!', 'success');
}

function resetTheme() {
    const defaultTheme = {
        primary: '#4a90e2',
        background: '#f8f9fa',
        text: '#333333'
    };

    document.getElementById('primaryColor').value = defaultTheme.primary;
    document.getElementById('backgroundColor').value = defaultTheme.background;
    document.getElementById('textColor').value = defaultTheme.text;

    applyCustomTheme(); // Reuse the apply function
    showNotification('Theme reset to default!', 'info');
}

function updateColorPreview(primary, background, text) {
    const previewHeader = document.querySelector('.preview-header');
    const previewContent = document.querySelector('.preview-content');
    const previewBtn = document.querySelector('.preview-btn');

    previewHeader.style.backgroundColor = primary;
    previewContent.style.backgroundColor = background;
    previewContent.style.color = text;
    previewBtn.style.backgroundColor = primary;
}

// ===========================================
// PART 3: FORM VALIDATION
// ===========================================

function setupRealTimeValidation() {
    const form = document.getElementById('registrationForm');
    
    // Real-time validation for each field
    form.addEventListener('input', function(e) {
        const target = e.target;
        
        switch(target.name) {
            case 'fullName':
                validateName(target.value);
                break;
            case 'email':
                validateEmail(target.value);
                break;
            case 'password':
                validatePassword(target.value);
                break;
            case 'confirmPassword':
                validateConfirmPassword(target.value);
                break;
            case 'age':
                validateAge(target.value);
                break;
        }
    });

    // Validate terms checkbox on change
    document.getElementById('terms').addEventListener('change', function() {
        validateTerms(this.checked);
    });
}

function handleFormSubmit(e) {
    e.preventDefault();
    console.log("Form submission handled...");

    // Validate all fields
    const isNameValid = validateName(document.getElementById('fullName').value);
    const isEmailValid = validateEmail(document.getElementById('email').value);
    const isPasswordValid = validatePassword(document.getElementById('password').value);
    const isConfirmValid = validateConfirmPassword(document.getElementById('confirmPassword').value);
    const isAgeValid = validateAge(document.getElementById('age').value);
    const isTermsValid = validateTerms(document.getElementById('terms').checked);

    if (isNameValid && isEmailValid && isPasswordValid && isConfirmValid && isAgeValid && isTermsValid) {
        // Form is valid - show success message
        showFormSuccess();
    } else {
        showNotification('Please fix the errors in the form before submitting.', 'error');
    }
}

// Individual validation functions
function validateName(name) {
    const errorElement = document.getElementById('nameError');
    const inputElement = document.getElementById('fullName');

    if (name.trim().length < 2) {
        showError(inputElement, errorElement, 'Name must be at least 2 characters long');
        return false;
    }

    if (!/^[a-zA-Z\s]+$/.test(name)) {
        showError(inputElement, errorElement, 'Name can only contain letters and spaces');
        return false;
    }

    clearError(inputElement, errorElement);
    return true;
}

function validateEmail(email) {
    const errorElement = document.getElementById('emailError');
    const inputElement = document.getElementById('email');

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    
    if (!emailRegex.test(email)) {
        showError(inputElement, errorElement, 'Please enter a valid email address');
        return false;
    }

    clearError(inputElement, errorElement);
    return true;
}

function validatePassword(password) {
    const errorElement = document.getElementById('passwordError');
    const inputElement = document.getElementById('password');

    const requirements = {
        length: password.length >= 8,
        uppercase: /[A-Z]/.test(password),
        number: /\d/.test(password),
        special: /[!@#$%^&*(),.?":{}|<>]/.test(password)
    };

    // Update requirement indicators
    updatePasswordRequirements(requirements);

    if (!requirements.length || !requirements.uppercase || !requirements.number || !requirements.special) {
        showError(inputElement, errorElement, 'Password does not meet all requirements');
        return false;
    }

    clearError(inputElement, errorElement);
    return true;
}

function updatePasswordRequirements(requirements) {
    const elements = {
        length: document.getElementById('req-length'),
        uppercase: document.getElementById('req-uppercase'),
        number: document.getElementById('req-number'),
        special: document.getElementById('req-special')
    };

    for (const [key, element] of Object.entries(elements)) {
        if (requirements[key]) {
            element.classList.add('valid');
        } else {
            element.classList.remove('valid');
        }
    }
}

function validateConfirmPassword(confirmPassword) {
    const errorElement = document.getElementById('confirmPasswordError');
    const inputElement = document.getElementById('confirmPassword');
    const password = document.getElementById('password').value;

    if (confirmPassword !== password) {
        showError(inputElement, errorElement, 'Passwords do not match');
        return false;
    }

    clearError(inputElement, errorElement);
    return true;
}

function validateAge(age) {
    const errorElement = document.getElementById('ageError');
    const inputElement = document.getElementById('age');

    if (age === '') return true; // Age is optional

    const ageNum = parseInt(age);
    if (isNaN(ageNum) || ageNum < 13 || ageNum > 120) {
        showError(inputElement, errorElement, 'Age must be between 13 and 120, or leave blank');
        return false;
    }

    clearError(inputElement, errorElement);
    return true;
}

function validateTerms(checked) {
    const errorElement = document.getElementById('termsError');
    
    if (!checked) {
        errorElement.textContent = 'You must agree to the terms and conditions';
        return false;
    }

    errorElement.textContent = '';
    return true;
}

// Helper functions for validation
function showError(inputElement, errorElement, message) {
    inputElement.classList.add('error');
    errorElement.textContent = message;
}

function clearError(inputElement, errorElement) {
    inputElement.classList.remove('error');
    errorElement.textContent = '';
}

function showFormSuccess() {
    const form = document.getElementById('registrationForm');
    const successMessage = document.getElementById('formSuccess');
    
    form.style.display = 'none';
    successMessage.style.display = 'block';
    
    // Optional: Reset form after delay
    setTimeout(() => {
        form.reset();
        form.style.display = 'block';
        successMessage.style.display = 'none';
        
        // Clear all errors
        const errorMessages = document.querySelectorAll('.error-message');
        errorMessages.forEach(el => el.textContent = '');
        
        const errorInputs = document.querySelectorAll('.error');
        errorInputs.forEach(el => el.classList.remove('error'));
        
        // Reset password requirements
        const requirementElements = document.querySelectorAll('.password-requirements li');
        requirementElements.forEach(el => el.classList.remove('valid'));
    }, 5000);
}

// ===========================================
// PART 4: IMAGE GALLERY WITH LIGHTBOX
// ===========================================

function initializeGallery() {
    console.log("Initializing image gallery...");
    
    // Sample images - in a real app, these would come from an API or file system
    appState.galleryImages = [
        { src: 'https://picsum.photos/400/300?random=1', alt: 'Landscape 1', type: 'landscape' },
        { src: 'https://picsum.photos/300/400?random=2', alt: 'Portrait 1', type: 'portrait' },
        { src: 'https://picsum.photos/400/300?random=3', alt: 'Landscape 2', type: 'landscape' },
        { src: 'https://picsum.photos/300/400?random=4', alt: 'Portrait 2', type: 'portrait' },
        { src: 'https://picsum.photos/400/300?random=5', alt: 'Landscape 3', type: 'landscape' },
        { src: 'https://picsum.photos/300/400?random=6', alt: 'Portrait 3', type: 'portrait' }
    ];

    renderGallery();
}

function renderGallery(images = appState.galleryImages) {
    const gallery = document.getElementById('imageGallery');
    gallery.innerHTML = '';

    images.forEach((image, index) => {
        const galleryItem = document.createElement('div');
        galleryItem.className = 'gallery-item';
        galleryItem.innerHTML = `
            <img src="${image.src}" alt="${image.alt}" loading="lazy">
        `;
        
        galleryItem.addEventListener('click', () => openLightbox(index));
        gallery.appendChild(galleryItem);
    });
}

function openLightbox(index) {
    appState.currentImageIndex = index;
    const lightbox = document.getElementById('lightbox');
    const lightboxImage = document.getElementById('lightbox-image');
    const caption = document.querySelector('.lightbox-caption');

    const image = appState.galleryImages[index];
    lightboxImage.src = image.src;
    lightboxImage.alt = image.alt;
    caption.textContent = image.alt;

    lightbox.classList.add('active');
    document.body.style.overflow = 'hidden'; // Prevent scrolling
}

function closeLightbox() {
    const lightbox = document.getElementById('lightbox');
    lightbox.classList.remove('active');
    document.body.style.overflow = ''; // Restore scrolling
}

function showNextImage() {
    appState.currentImageIndex = (appState.currentImageIndex + 1) % appState.galleryImages.length;
    updateLightboxImage();
}

function showPreviousImage() {
    appState.currentImageIndex = (appState.currentImageIndex - 1 + appState.galleryImages.length) % appState.galleryImages.length;
    updateLightboxImage();
}

function updateLightboxImage() {
    const lightboxImage = document.getElementById('lightbox-image');
    const caption = document.querySelector('.lightbox-caption');
    
    const image = appState.galleryImages[appState.currentImageIndex];
    lightboxImage.src = image.src;
    lightboxImage.alt = image.alt;
    caption.textContent = image.alt;
}

function handleKeyboardNavigation(e) {
    const lightbox = document.getElementById('lightbox');
    if (!lightbox.classList.contains('active')) return;

    switch(e.key) {
        case 'Escape':
            closeLightbox();
            break;
        case 'ArrowLeft':
            showPreviousImage();
            break;
        case 'ArrowRight':
            showNextImage();
            break;
    }
}

function shuffleGallery() {
    // Fisher-Yates shuffle algorithm
    for (let i = appState.galleryImages.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [appState.galleryImages[i], appState.galleryImages[j]] = [appState.galleryImages[j], appState.galleryImages[i]];
    }
    renderGallery();
    showNotification('Gallery shuffled!', 'success');
}

function filterGallery(type) {
    let filteredImages;
    
    switch(type) {
        case 'landscape':
            filteredImages = appState.galleryImages.filter(img => img.type === 'landscape');
            break;
        case 'portrait':
            filteredImages = appState.galleryImages.filter(img => img.type === 'portrait');
            break;
        default:
            filteredImages = appState.galleryImages;
    }
    
    renderGallery(filteredImages);
    showNotification(`Showing ${type} images`, 'info');
}

// ===========================================
// UTILITY FUNCTIONS
// ===========================================

function showNotification(message, type = 'info') {
    // Create notification element
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    notification.innerHTML = `
        <span>${message}</span>
        <button onclick="this.parentElement.remove()">&times;</button>
    `;

    // Add styles for notification
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        padding: 1rem 1.5rem;
        background: ${type === 'error' ? '#dc3545' : type === 'warning' ? '#ffc107' : type === 'success' ? '#28a745' : '#17a2b8'};
        color: white;
        border-radius: 5px;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        z-index: 10000;
        display: flex;
        justify-content: space-between;
        align-items: center;
        gap: 1rem;
        max-width: 400px;
        animation: slideIn 0.3s ease-out;
    `;

    document.body.appendChild(notification);

    // Auto-remove after 5 seconds
    setTimeout(() => {
        if (notification.parentElement) {
            notification.remove();
        }
    }, 5000);
}

// ===========================================
// INITIALIZATION
// ===========================================

// Wait for DOM to be fully loaded before initializing
document.addEventListener('DOMContentLoaded', function() {
    console.log("Week 6 Assignment - Interactive Web App Initializing...");
    
    initializeEventListeners();
    initializeTaskManager();
    initializeGallery();
    
    console.log("Application initialized successfully!");
});

// Make functions globally available for HTML event handlers
window.toggleTaskCompletion = toggleTaskCompletion;
window.editTask = editTask;
window.deleteTask = deleteTask;